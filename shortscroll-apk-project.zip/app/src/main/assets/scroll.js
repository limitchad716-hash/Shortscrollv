(function () {
  if (window.__shortScroll) return;
  window.__shortScroll = true;
  var delaySec = 3, running = false, last = null;

  var btn = document.createElement("button");
  btn.style.cssText = "position:fixed;top:8px;right:8px;z-index:2147483647;padding:8px 12px;border-radius:16px;border:0;background:#222;color:#fff;font:13px sans-serif;opacity:.85";
  function label() { btn.textContent = (running ? "Auto-scroll ON" : "Auto-scroll OFF") + " · " + delaySec + "s"; }
  btn.onclick = function () { running = !running; last = null; label(); };
  btn.oncontextmenu = function (e) { e.preventDefault(); delaySec = delaySec >= 10 ? 0 : delaySec + 1; label(); };
  label();
  document.documentElement.appendChild(btn);

  function nextVideo() {
    var yt = document.querySelector("#navigation-button-down button");
    if (yt) { yt.click(); return; }
    var o = { key: "ArrowDown", code: "ArrowDown", keyCode: 40, which: 40, bubbles: true };
    document.dispatchEvent(new KeyboardEvent("keydown", o));
    document.dispatchEvent(new KeyboardEvent("keyup", o));
  }
  function current() {
    var vs = Array.prototype.slice.call(document.querySelectorAll("video"));
    return vs.find(function (v) {
      var r = v.getBoundingClientRect();
      return r.top < innerHeight * 0.7 && r.bottom > innerHeight * 0.3;
    }) || vs[0] || null;
  }
  setInterval(function () {
    if (!running) return;
    var v = current(); if (!v) return;
    if (v !== last) { last = v; v._d = false; v._p = 0; }
    var wrapped = v._p > 1 && v.currentTime < v._p - 1;
    v._p = v.currentTime;
    if ((v.ended || wrapped) && !v._d) {
      v._d = true;
      setTimeout(function () { if (running) nextVideo(); }, delaySec * 1000);
    }
  }, 500);
})();
