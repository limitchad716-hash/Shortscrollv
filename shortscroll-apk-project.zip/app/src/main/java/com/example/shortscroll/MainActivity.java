package com.example.shortscroll;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView web;
    private String script = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try (InputStream in = getAssets().open("scroll.js")) {
            script = new String(in.readAllBytes(), "UTF-8");
        } catch (Exception ignored) {}

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(script, null);
            }
        });
        setContentView(web);
        web.loadUrl("https://www.youtube.com/shorts");
    }

    @Override public boolean onCreateOptionsMenu(Menu m) {
        m.add(0, 1, 0, "YouTube Shorts");
        m.add(0, 2, 0, "TikTok");
        m.add(0, 3, 0, "Facebook Reels");
        return true;
    }

    @Override public boolean onOptionsItemSelected(MenuItem i) {
        switch (i.getItemId()) {
            case 1: web.loadUrl("https://www.youtube.com/shorts"); return true;
            case 2: web.loadUrl("https://www.tiktok.com/"); return true;
            case 3: web.loadUrl("https://www.facebook.com/reel/"); return true;
        }
        return super.onOptionsItemSelected(i);
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
